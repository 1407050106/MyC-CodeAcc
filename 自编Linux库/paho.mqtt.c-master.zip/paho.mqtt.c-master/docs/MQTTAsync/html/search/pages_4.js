var searchData=
[
  ['subscription_20example_701',['Subscription example',['../subscribe.html',1,'']]],
  ['subscription_20wildcards_702',['Subscription wildcards',['../wildcard.html',1,'']]]
];
