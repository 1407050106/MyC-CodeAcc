import Vue from 'vue'

export declare class Contextmenu extends Vue {
  show: (e: MouseEvent) => void
}
